package com.dailysmart.app.data.repository

import com.dailysmart.app.data.local.dao.FinanceDao
import com.dailysmart.app.data.local.dao.HabitDao
import com.dailysmart.app.data.local.dao.TaskDao
import com.dailysmart.app.data.local.entity.HabitCheckInEntity
import com.dailysmart.app.data.local.entity.HabitEntity
import com.dailysmart.app.data.local.entity.TaskEntity
import com.dailysmart.app.data.local.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow

class DailySmartRepository(
    private val taskDao: TaskDao,
    private val habitDao: HabitDao,
    private val financeDao: FinanceDao
) {
    // ----- Tâches -----
    val tasks: Flow<List<TaskEntity>> = taskDao.getAllTasks()

    suspend fun addTask(title: String) {
        taskDao.insertTask(TaskEntity(title = title))
    }

    suspend fun setTaskCompleted(task: TaskEntity, completed: Boolean) {
        taskDao.toggleTaskCompletion(
            taskId = task.id,
            isCompleted = completed,
            completedAt = if (completed) System.currentTimeMillis() else null
        )
    }

    suspend fun deleteTask(task: TaskEntity) {
        taskDao.deleteTask(task)
    }

    // ----- Habitudes -----
    val habits: Flow<List<HabitEntity>> = habitDao.getAllHabits()

    fun checkInsFor(dateIso: String): Flow<List<HabitCheckInEntity>> =
        habitDao.getCheckInsForDate(dateIso)

    suspend fun habitCount(): Int = habitDao.countHabits()

    suspend fun addHabit(title: String) {
        habitDao.insertHabit(HabitEntity(title = title))
    }

    suspend fun setHabitDone(habitId: Long, dateIso: String, done: Boolean) {
        if (done) {
            habitDao.insertCheckIn(HabitCheckInEntity(habitId = habitId, dateIso = dateIso))
        } else {
            habitDao.deleteCheckIn(habitId, dateIso)
        }
    }

    suspend fun deleteHabit(habit: HabitEntity) {
        habitDao.deleteCheckInsForHabit(habit.id)
        habitDao.deleteHabit(habit)
    }

    // ----- Finances -----
    val transactions: Flow<List<TransactionEntity>> = financeDao.getAllTransactions()

    suspend fun addTransaction(transaction: TransactionEntity) {
        financeDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        financeDao.deleteTransaction(transaction)
    }
}
