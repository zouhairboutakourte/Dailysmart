package com.dailysmart.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dailysmart.app.data.local.entity.HabitCheckInEntity
import com.dailysmart.app.data.local.entity.HabitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY id ASC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Query("SELECT COUNT(*) FROM habits")
    suspend fun countHabits(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("DELETE FROM habit_checkins WHERE habitId = :habitId")
    suspend fun deleteCheckInsForHabit(habitId: Long)

    @Query("SELECT * FROM habit_checkins WHERE dateIso = :dateIso")
    fun getCheckInsForDate(dateIso: String): Flow<List<HabitCheckInEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCheckIn(checkIn: HabitCheckInEntity): Long

    @Query("DELETE FROM habit_checkins WHERE habitId = :habitId AND dateIso = :dateIso")
    suspend fun deleteCheckIn(habitId: Long, dateIso: String)
}
