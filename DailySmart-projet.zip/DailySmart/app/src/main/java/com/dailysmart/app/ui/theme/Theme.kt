package com.dailysmart.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B1F3A)
val NavyLight = Color(0xFF1F3C6B)

private val LightColors = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9E2F3),
    onPrimaryContainer = Navy,
    secondary = NavyLight,
    onSecondary = Color.White,
    background = Color(0xFFF5F7FB),
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE8EDF6),
    onSurfaceVariant = Color(0xFF3B4658)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9DB8E8),
    onPrimary = Navy,
    primaryContainer = Color(0xFF1F3C6B),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFF7FA0D8),
    onSecondary = Navy,
    background = Color(0xFF07142A),
    onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF0E2038),
    onSurface = Color(0xFFE6EAF2),
    surfaceVariant = Color(0xFF16294A),
    onSurfaceVariant = Color(0xFFC3CCDB)
)

@Composable
fun DailySmartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
