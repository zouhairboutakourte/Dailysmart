package com.dailysmart.app.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.dailysmart.app.R

sealed class Screen(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector
) {
    object Home : Screen("home", R.string.nav_home, Icons.Filled.Home)
    object Tasks : Screen("tasks", R.string.nav_tasks, Icons.Filled.CheckCircle)
    object Habits : Screen("habits", R.string.nav_habits, Icons.Filled.Favorite)
    object Finances : Screen("finances", R.string.nav_finances, Icons.Filled.AccountBalanceWallet)
    object Settings : Screen("settings", R.string.nav_settings, Icons.Filled.Settings)

    companion object {
        val items: List<Screen> get() = listOf(Home, Tasks, Habits, Finances, Settings)
    }
}
