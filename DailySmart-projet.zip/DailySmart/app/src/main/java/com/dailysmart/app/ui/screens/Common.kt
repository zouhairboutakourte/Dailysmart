package com.dailysmart.app.ui.screens

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import com.dailysmart.app.R
import java.util.Locale

val EXPENSE_CATEGORIES = listOf("food", "transport", "health", "bills", "leisure", "savings", "other")

fun formatMoney(value: Double): String = String.format(Locale.US, "%,.2f", value)

/** Les 4 habitudes d'exemple sont enregistrées sous forme de code (@fajr...) pour pouvoir être traduites. */
@Composable
fun habitDisplayName(title: String): String = when (title) {
    "@fajr" -> stringResource(R.string.habit_fajr)
    "@water" -> stringResource(R.string.habit_water)
    "@read" -> stringResource(R.string.habit_read)
    "@exercise" -> stringResource(R.string.habit_exercise)
    else -> title
}

@Composable
fun categoryDisplayName(key: String): String = when (key) {
    "food" -> stringResource(R.string.cat_food)
    "transport" -> stringResource(R.string.cat_transport)
    "health" -> stringResource(R.string.cat_health)
    "bills" -> stringResource(R.string.cat_bills)
    "leisure" -> stringResource(R.string.cat_leisure)
    "savings" -> stringResource(R.string.cat_savings)
    "other" -> stringResource(R.string.cat_other)
    "income" -> stringResource(R.string.fin_income)
    else -> key
}

@Composable
fun AddTextDialog(
    title: String,
    hint: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(hint) },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}
