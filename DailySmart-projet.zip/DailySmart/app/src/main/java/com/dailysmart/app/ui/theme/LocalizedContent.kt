package com.dailysmart.app.ui.theme

import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

/**
 * Change la langue des textes (stringResource) et le sens de l'écran
 * (droite-à-gauche pour l'arabe) pour tout ce qui est à l'intérieur.
 */
@Composable
fun LocalizedContent(languageCode: String, content: @Composable () -> Unit) {
    val baseContext = LocalContext.current
    val locale = remember(languageCode) { Locale(languageCode) }
    val config = remember(languageCode, baseContext) {
        Configuration(baseContext.resources.configuration).apply {
            setLocale(locale)
            setLayoutDirection(locale)
        }
    }
    val localizedContext = remember(config, baseContext) {
        baseContext.createConfigurationContext(config)
    }
    val direction = if (languageCode == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalConfiguration provides config,
        LocalLayoutDirection provides direction
    ) {
        content()
    }
}
