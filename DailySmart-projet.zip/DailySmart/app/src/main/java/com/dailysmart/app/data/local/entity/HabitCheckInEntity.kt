package com.dailysmart.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "habit_checkins",
    indices = [Index(value = ["habitId", "dateIso"], unique = true)]
)
data class HabitCheckInEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val habitId: Long,
    val dateIso: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)
