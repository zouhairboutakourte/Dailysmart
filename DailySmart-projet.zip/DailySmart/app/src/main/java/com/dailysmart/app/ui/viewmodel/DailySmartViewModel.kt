package com.dailysmart.app.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dailysmart.app.DailySmartApplication
import com.dailysmart.app.data.local.entity.HabitCheckInEntity
import com.dailysmart.app.data.local.entity.HabitEntity
import com.dailysmart.app.data.local.entity.TaskEntity
import com.dailysmart.app.data.local.entity.TransactionEntity
import com.dailysmart.app.data.local.entity.TransactionType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class DailySmartViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = getApplication<DailySmartApplication>().repository
    private val prefs = application.getSharedPreferences("dailysmart_prefs", Context.MODE_PRIVATE)

    // Date du jour (format 2026-11-08)
    private val today: String = LocalDate.now().toString()

    val tasks: StateFlow<List<TaskEntity>> = repository.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habits: StateFlow<List<HabitEntity>> = repository.habits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayCheckIns: StateFlow<List<HabitCheckInEntity>> = repository.checkInsFor(today)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Langue par défaut : arabe
    private val _language = MutableStateFlow(prefs.getString("language", "ar") ?: "ar")
    val language: StateFlow<String> = _language

    init {
        // Au premier lancement : 4 habitudes d'exemple
        viewModelScope.launch {
            if (!prefs.getBoolean("habits_seeded", false)) {
                if (repository.habitCount() == 0) {
                    listOf("@fajr", "@water", "@read", "@exercise").forEach {
                        repository.addHabit(it)
                    }
                }
                prefs.edit().putBoolean("habits_seeded", true).apply()
            }
        }
    }

    fun setLanguage(code: String) {
        prefs.edit().putString("language", code).apply()
        _language.value = code
    }

    // ----- Tâches -----
    fun addTask(title: String) {
        viewModelScope.launch { repository.addTask(title) }
    }

    fun setTaskCompleted(task: TaskEntity, completed: Boolean) {
        viewModelScope.launch { repository.setTaskCompleted(task, completed) }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch { repository.deleteTask(task) }
    }

    // ----- Habitudes -----
    fun addHabit(title: String) {
        viewModelScope.launch { repository.addHabit(title) }
    }

    fun setHabitDone(habitId: Long, done: Boolean) {
        viewModelScope.launch { repository.setHabitDone(habitId, today, done) }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch { repository.deleteHabit(habit) }
    }

    // ----- Finances -----
    fun addTransaction(title: String, amount: Double, type: TransactionType, category: String) {
        viewModelScope.launch {
            repository.addTransaction(
                TransactionEntity(
                    title = title,
                    amount = amount,
                    type = type,
                    category = category,
                    dateIso = today
                )
            )
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch { repository.deleteTransaction(transaction) }
    }
}
