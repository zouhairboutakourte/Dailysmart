# Daily Smart — Application Android

Application gratuite, sans publicité, hors connexion. Arabe (par défaut), français, anglais.
Kotlin + Jetpack Compose (Material 3) + Room.

Sections : Accueil (progression du jour), Tâches, Habitudes, Finances, Paramètres.

L'APK (version debug) est compilé automatiquement par GitHub Actions.
