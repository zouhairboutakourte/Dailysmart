# Générer l'APK (sans Android Studio)

Le fichier .github/workflows/build-apk.yml compile l'APK sur GitHub (gratuit).
Après chaque envoi sur la branche `dev`, ouvrir l'onglet Actions, choisir la dernière exécution,
puis télécharger l'artefact `DailySmart-APK`.

Cet APK est de type "debug" : il s'installe directement sur un téléphone Android, sans clé de signature.
